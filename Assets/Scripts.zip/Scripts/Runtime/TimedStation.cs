using UnityEngine;
using VContainer;
using MyOvercooked.Data;

namespace MyOvercooked.Runtime
{
    /// <summary>
    /// Bếp nấu (Stove/Oven) — Đặt đồ vào là tự chạy quá trình nấu (không cần đứng giữ phím).
    /// </summary>
    public class TimedStation : StationBase, IInteractable
    {
        [Header("Station Settings")]
        [Tooltip("Loại bàn (thường là Stove)")]
        public StationType stationType = StationType.Stove;

        [Header("UI")]
        [Tooltip("Vòng tròn ProgressUI hiển thị tiến trình nấu")]
        public ProgressUI progressUI;

        [Tooltip("Kéo file RecipeDatabaseSO vào đây nếu không dùng VContainer")]
        [SerializeField] private RecipeDatabaseSO _recipeDatabase;
        
        // Trạng thái nấu
        private bool _isCooking = false;
        private float _cookingProgress = 0f;
        private float _cookingDuration = 0f;
        private TransformationSO _currentRecipe = null;

        [Inject]
        public void Construct(RecipeDatabaseSO recipeDatabase)
        {
            if (recipeDatabase != null) _recipeDatabase = recipeDatabase;
        }

        // =========================================================
        // Khả năng tương tác (Dùng cho UI Prompt)
        // =========================================================
        public bool CanInteract(PlayerInteraction player)
        {
            return (!player.IsHoldingFood && HasFood) || (player.IsHoldingFood && !HasFood);
        }

        public bool CanInteractHold(PlayerInteraction player) => false; // Bếp lò tự nấu, không dùng F

        // =========================================================
        // Bấm 1 lần (Interact): Đặt đồ / Lấy đồ
        // =========================================================
        public void Interact(PlayerInteraction player)
        {
            // Trường hợp 1: Tay rảnh, Bếp có đồ -> Nhặt lên
            if (!player.IsHoldingFood && HasFood)
            {
                // Khi lấy đồ ra, bếp ngừng nấu
                CancelCooking();

                FoodItem foodToTake = TryRemoveFood();
                player.PickupFood(foodToTake);
                return;
            }

            // Trường hợp 2: Tay có đồ, Bếp trống -> Đặt xuống
            if (player.IsHoldingFood && !HasFood)
            {
                FoodItem foodToDrop = player.ReleaseFood();
                TryAddFood(foodToDrop);
                
                // Đặt xuống xong thì kiểm tra xem có nấu được không
                CheckAndStartCooking();
                return;
            }

            // Trường hợp 3: Có dĩa (hoặc tay cầm dĩa hoặc bếp đang có dĩa)
            if (player.IsHoldingFood && HasFood)
            {
                // Nếu vật trên bếp là dĩa
                Plate plateOnStove = CurrentFood.GetComponent<Plate>();
                if (plateOnStove != null && plateOnStove.CanInteract(player))
                {
                    plateOnStove.Interact(player);
                    return;
                }

                // Nếu vật trên tay là dĩa -> Nhặt đồ từ bếp bỏ vào dĩa
                Plate heldPlate = player.CurrentHeldFood.GetComponent<Plate>();
                if (heldPlate != null)
                {
                    CancelCooking();
                    FoodItem foodToTake = TryRemoveFood();
                    heldPlate.AddIngredient(foodToTake);
                    return;
                }
            }

            Debug.Log("[TimedStation] Không thể tương tác (bếp đã có đồ hoặc tay đang có đồ)!");
        }

        // =========================================================
        // Giữ phím (InteractHold): Không làm gì với bếp lò
        // =========================================================
        public bool InteractHold(PlayerInteraction player, float deltaTime)
        {
            // Bếp tự nấu, không cần đứng đè phím E
            return false;
        }

        public void CancelInteract()
        {
            // Không dùng cho TimedStation
        }

        // =========================================================
        // Logic Nấu ăn tự động
        // =========================================================
        private void CheckAndStartCooking()
        {
            if (!HasFood) return;

            FoodStateSO[] inputs = new FoodStateSO[] { CurrentFood.CurrentData };

            if (_recipeDatabase.TryGetTransformation(inputs, stationType, out TransformationSO result))
            {
                _currentRecipe = result;
                _cookingDuration = result.duration > 0 ? result.duration : 1f;
                _cookingProgress = 0f;
                _isCooking = true;
                
                Debug.Log($"[TimedStation] Bắt đầu nấu: <b>{_currentRecipe.output.id}</b> trong {_cookingDuration}s");
            }
            else
            {
                Debug.Log($"[TimedStation] Không có công thức cho món này trên lò!");
            }
        }

        private void CancelCooking()
        {
            if (_isCooking)
            {
                _isCooking = false;
                _cookingProgress = 0f;
                _currentRecipe = null;
                
                if (progressUI != null)
                {
                    progressUI.Hide();
                }
                
                Debug.Log("[TimedStation] Đã ngừng nấu do đồ bị lấy ra!");
            }
        }

        private void Update()
        {
            if (!_isCooking) return;

            _cookingProgress += Time.deltaTime;

            if (progressUI != null)
            {
                progressUI.ShowProgress(_cookingProgress, _cookingDuration);
            }

            if (_cookingProgress >= _cookingDuration)
            {
                // Nấu xong
                CurrentFood.Setup(_currentRecipe.output);
                Debug.Log($"[TimedStation] Xèo Xèo... Đã nấu xong: <b>{_currentRecipe.output.id}</b>");
                
                // Reset
                _isCooking = false;
                _cookingProgress = 0f;
                _currentRecipe = null;
                
                if (progressUI != null)
                {
                    progressUI.Hide();
                }
            }
        }
    }
}
